# AI 提示词改造 · 当前项目状态与 AI 使用统计说明

| 字段 | 值 |
|---|---|
| 文档名称 | AI 提示词改造计划：当前项目状态与 AI 使用统计 |
| 存放位置 | `docs/temp/`（交接/改造对照，**不是**产品需求真源） |
| 快照日期 | 2026-09-20 |
| 当前分支 | `feature/huanpipro` |
| 当前 Commit | `9a52349e`（已与 origin 对齐） |
| 仓库 Git 已跟踪文件 | 5855 |
| 配套治理模板 | `docs/governance/common_prd_v3.1/` **v3.1.15** |
| 拟定改造对象 | `通用文档提示词v3.1.md`、`通用文档提示词v3.1完整使用说明.md` |
| 改造硬约束 | **不得破坏本仓库业务代码、配置、SQL、前端工程**；默认只改治理提示词及必要的配套说明 |

本文给后续「改造 v3.1 提示词」当现状盘点。正式业务仍以 `docs/project/prd/` 为准；部署端口以 DEC-049 / DEC-067 与 `.cursor/rules/port-binding.mdc` 为准。`docs/temp` 按项目变量第 5 条：**只读参考，不作为维护文档迭代**。

---

## 0. 这份说明要回答什么

后续改造提示词时，必须先看清三件事：

1. **整个 git 仓库怎么摆**：哪些是现码、哪些是文档、哪些被项目明确忽略。
2. **`docs/project` 已经生成了多少、到了哪一闸**：G0～G11、DEC/ADR/CR、UI_SPEC、白话、工作日志。
3. **代码工程真实目录**：五端进程、三套 UniApp、后台 Vue，避免提示词改完后 AI 把目录写错或去改不该碰的树。

改造提示词时允许动：`docs/governance/common_prd_v3.1/`（及你点名的配套说明）。  
改造提示词时默认禁止动：`nunu-go-api/`、`go-uni-app*`、`deploy/sql`、业务配置、已批准 PRD/DEC/ADR 正文（除非另开口令）。

---

## 1. 仓库整体目录（整个 git）

仓库根：`/Users/mac/MYCODES/AICODE/x_shop_server/x_shop_server`。  
Git 已跟踪的**一级目录**：

| 路径 | 角色 | 已跟踪约略 | 改造提示词时 |
|---|---|---|---|
| `nunu-go-api/` | Go monorepo：五端 API + 两套后台 Vue + 三套 H5 静态进程 | 2342 文件 | **禁止改代码** |
| `go-uni-app/` | 众享营销 - 本地生活 C 端（UniApp） | 1219 | **禁止改代码** |
| `go-uni-app-online/` | 众享源品 - 在线商城 C 端 | 1000 | **禁止改代码** |
| `go-uni-app-tob/` | ToB 营销 C 端 | 354 | **禁止改代码** |
| `docs/` | 治理模板 + 项目文档 + temp | 878 | 仅允许改你点名的提示词；`docs/project` 真源不要顺手改 |
| `tools/anydesign/` | anydesign Python 技能源码 | 计入 tools/.cursor 共 54 | 非本次对象 |
| `.cursor/` | 规则与技能软链 | 同上 | 非本次对象，除非提示词要引用路径 |
| `.gitignore` / `jenkinsfile` / `README.md` / `LICENSE` | 仓库元数据 | — | 不要动 |

根目录上还有**未纳入「现码真源」、或被 G0 明确忽略**的本地项：

| 路径 | 说明 |
|---|---|
| `cmd/`、`storage/`、`.idea/`、`.htaccess`、`package-lock.json`、`upgrade.md` | 根上残留/IDE/运维碎片，不是本期文档真源 |
| `nunu-go-api/mall-uniapp/` | **G0 约束：忽略、不做任何考虑**（本地仍在） |
| 仓库根 `admin/`、`uni-app/`、`niucloud/` | G0 约定忽略；本机快照时**不存在** |
| `nunu-go-api/docs/` | G0：已脱节，不以它为真源；本机快照时不存在 |
| `docs/temp/` | 只读参考袋；本文也在这里 |

```text
x_shop_server/                          # git 根
├── .cursor/                            # Cursor 规则与技能
│   ├── rules/                          # collaboration-judgment / port-binding / ui-spec-gate
│   └── skills/
│       ├── anydesign -> ../../tools/anydesign
│       └── visual-repair-loop/
├── docs/
│   ├── governance/common_prd_v3.1/     # ★ 拟改造的 AI 提示词
│   ├── project/                        # ★ 本项目文档真源（G0～G11 产物）
│   ├── temp/                           # 交接/对照，非正式真源
│   ├── DevelopmentEvaluation/          # 历史评估，非正式真源
│   ├── agreements/                     # 协议类，非正式维护真源
│   └── iteration-2.0/                  # 历史迭代袋
├── nunu-go-api/                        # Go 后端 monorepo
├── go-uni-app/                         # 本地生活 C 端
├── go-uni-app-online/                  # 源品 C 端
├── go-uni-app-tob/                     # ToB C 端
└── tools/anydesign/                    # 设计提取脚本（.venv 不入库）
```

### 1.1 五端端口（提示词/AI 写文档时不得写串）

| 前端 | 热更新 | 只调本机接口 | 禁止接到 |
|---|---|---|---|
| `nunu-go-api/app/admin/web` | 5173 | **8031** admin | 8032 / 8033 / 8035 / 8037 |
| `nunu-go-api/app/merchant/web` | 5174 | **8033** merchant | 8031 / 8032 / 8035 / 8037 |
| `go-uni-app` | 5175 `/wap/` | **8032** mall；H5 8034 `/wap/` | 8035 / 8033 / 8037 |
| `go-uni-app-online` | 5176 根路径 | **8035** mall-online；H5 8036 根路径 | **8032 / 8033 / 8037** |
| `go-uni-app-tob` | 5177 `/wap/` | **8037** mall-tob；H5 8038 `/wap/` | **8032 / 8033 / 8035** |

测试域名一律 `.gyyx.store`，正式一律 `.zhengdeyunqi.cn`。源品附近 Tab 也只打 8035。

---

## 2. 文档生成内容统计（`docs/project`）

`DOC_ROOT=docs/project/`。快照：约 **742 个文件、约 37 MB**（含设计图/循环截图/来源袋图片）。

文档进度真源：`progress/PROGRESS_REGISTER.yaml`；人读：`progress/DOCUMENT_PROGRESS.md`、`progress/PROJECT_DASHBOARD.md`。

| 指标 | 当前值 |
|---|---|
| 文档进度（加权） | **69%**（11790 / 170） |
| 开发执行进度 | **0%**（看板口径：未合 main 不虚涨） |
| `PROJECT_STAGE` | `IMPLEMENTATION` |
| `REPOSITORY_ROLE` | `CURRENT_BASELINE` |
| `ALLOW_CODE_CHANGES` | `true`（仅点名批次） |
| 业务真源 PRD | **v0.1.44 Approved**（CR-051 / DEC-073）；**不是** Baselined |
| 上一盖章 PRD | Baselined **v0.1.29** 只读 |
| 技术基线 | TECH_BASELINE **v0.1.5**（G6～G9 Baselined） |
| 治理模板 | v3.1.15 |
| P0 / P1 | 无 |

### 2.1 分目录文件量

| 目录 | 文件数 | 约体积 | 职责 |
|---|---:|---:|---|
| `sources/` | 33 | 18 MB | 原始资料；BATCH-001/002 冻结；BATCH-003 为设计源转存 |
| `baseline/` | 81 | 408 KB | 来源盘点 + **DEC-001～073** |
| `prd/` | 17 | 256 KB | 总 PRD + 模块 PRD |
| `acceptance/` | 6 | 44 KB | TRACE / OPEN_ITEMS |
| `architecture/` | 7 | 68 KB | G6 五份 + G7 边界 |
| `design/` | 13 | 124 KB | G8 十个能力域设计 |
| `api/` | 6 | 24 KB | G9 API 契约 |
| `database/` | 4 | 28 KB | G9 数据模型/迁移计划 |
| `standards/` | 4 | 20 KB | G9 工程规范 |
| `ui-design/` | 132 | 16.4 MB | G9.1 应用目录 + 源品 UI_SPEC + 视觉循环截图 |
| `decisions/` | 51 | 204 KB | **ADR-001～049** |
| `changes/` | 54 | 220 KB | **CR-001～051** |
| `progress/` | 235 | 1.0 MB | 看板、寄存器、**工作日志 220 篇** |
| `delivery/` | 9 | 60 KB | G10 批次 + 源品 Partial Contract |
| `plain-document/` | 71 | 420 KB | 对外白话（第 36B～36D 节产物） |
| `plain-spec/` | 8 | 124 KB | 白话施工细则 |
| `operations/` | 1 | 4 KB | 未展开 |
| `iteration-suggestions/` | 2 | 8 KB | 仅预留 |
| `templates/` | 5 | 20 KB | G0 模板 |

治理目录（不在 `docs/project` 内，但是 AI 每次必载）：

| 路径 | 文件数 | 约体积 |
|---|---:|---:|
| `docs/governance/` | 10 | 364 KB |
| 其中 `common_prd_v3.1/` | 10 | 352 KB |

### 2.2 G 阶段闸口（提示词 G0～G11 在本仓库的落地）

| 阶段 | 状态 | 本仓库证据 |
|---|---|---|
| G0 文档初始化 | 已完成 | `README.md`、`PROJECT_VARIABLES.md`、`AI_DOCUMENTATION_GUIDE.md` |
| G1 资料投放 | 已完成 | `sources/`；冻结 BATCH-001+002 |
| G2 来源和决策基线 | Draft（决策已大量应用） | `baseline/`；DEC 73 份 |
| G3 PRD 准入 | PASS | 看板 |
| G4 PRD Draft | 已完成 | Draft 历史保留 |
| G5 PRD 批准 | **Approved v0.1.44**（非 Baselined） | `prd/PRODUCT_PRD.md` + `prd/modules/` |
| G5.5 UI 逻辑范围 | 已完成 | `ui-design/UI_SCOPE_MAP.md`（逻辑范围，不生成 UI_SPEC） |
| G6 总体架构 | **Baselined** | 五份 architecture + ADR-040 |
| G7 模块边界 | **Baselined** | `MODULE_BOUNDARIES.md` + ADR-007～019 |
| G8 模块设计 | **Baselined** | `design/modules/` 十份 + ADR-041 |
| G9 API/数据/规范 | **Baselined** | `api/` `database/` `standards/` + ADR-043 |
| G9.1 UI 应用目录 | 已生成 | 六个 slug；ADR-044 |
| G9.5 可选 UI 规范 | **源品分闸已开** | 见下节；其它应用关闭 |
| G10 开发批次 | Draft | `delivery/DEVELOPMENT_BATCHES.md`；ADR-045 |
| G11 开发实施 | 已进入 | DEV-001～014 见批次表 |

### 2.3 编号资产（AI 已写入、禁止改挂主题）

| 类型 | 数量 | 号段 | 存放 |
|---|---:|---|---|
| DEC | **73** | 001～073 | `baseline/DEC-*.md` |
| ADR | **49** | 001～049 | `decisions/ADR-*.md` |
| CR | **51** | 001～051 | `changes/CR-*.md` |
| UI-DEC | **6** | 001～006 | `ui-design/UI-DEC-*.md` |
| 模块 PRD | **12** | M01～M12（产品地图另有 M13 ToB） | `prd/modules/` |
| 技术设计模块 | **11**（含 README） | tree / onboarding / goods / fulfillment / group-seckill / trade / user / auth-session / platform-ops / promotion | `design/modules/` |
| REQ 行（总 PRD 表） | **75** 行 | REQ-001 起，含 REQ-130～134 | `prd/PRODUCT_PRD.md` |

**编号占用规则（v3.1.11）已在本仓库生效：** 已占用号禁止改挂另一主题。改造提示词时不要发明「重排 DEC 号」的流程。

### 2.4 模块 PRD 地图（M01～M13）

| 编号 | 文件 | 主题 |
|---|---|---|
| M01 | `M01-business-type.md` | 业态、经营类目、抽佣 |
| M02 | `M02-onboarding.md` | 入驻与审店 |
| M03 | `M03-merchant-workspace.md` | 租户后台与四套菜单 |
| M04 | `M04-goods.md` | 商品与审核 |
| M05 | `M05-local-life.md` | 本地生活履约 |
| M06 | `M06-group-seckill.md` | 本地生活拼团秒杀 |
| M07 | `M07-online-mall.md` | 众享源品 - 在线商城 |
| M08 | `M08-user-pool.md` | 用户分池 |
| M09 | `M09-auth-session.md` | 登录会话 |
| M10 | `M10-order-settlement.md` | 订单支付结算 |
| M11 | `M11-platform-ops.md` | 平台运营 |
| M12 | `M12-promoter.md` | 推广员（现码保留） |
| M13 | 写在总 PRD 功能地图 | ToB 营销（CR-042） |

### 2.5 G9.5 / 源品 UI（提示词第 23A、25A、28A、29、32A 节的实际用量）

| 项 | 值 |
|---|---|
| 总闸 | `ENABLE_UI_SPEC_GENERATION=true` |
| 分闸应用 | **仅** `gongyi_online`（UI-DEC-001） |
| 其它应用 | `UI_CONSTRAINT_MODE=NONE`，跳过 G9.5 |
| 当前 UI_SPEC | `products/gongyi_online/UI_SPEC.md` **0.1.5 Approved Partial** |
| 历史冻结 | `UI_SPEC-0.1.0`～`0.1.4` 及各 Draft，共 12 个 UI_SPEC 文件 |
| Partial 范围 | 底栏、首页、分类、附近列表（`/addon/shop/pages/nearby/index-f`） |
| 生效合同 | `delivery/ui-contracts/gongyi_online-partial-001/` **0.1.5** |
| 店详情 | **不在** 0.1.5 换皮范围 |
| 视觉循环 | 第 32A 节独立手续；已跑 7 次 LOOP_RUNS（底栏/首页/分类/附近） |
| anydesign | `tools/anydesign/` + `.cursor/skills/anydesign` |

UI 应用目录六个 slug（G9.1，非正式 UI_SPEC，除源品外不启用）：

`admin_web`、`merchant_web`、`onboarding_h5`、`local_life_miniapp`、`gongyi_online`、`gongyi_h5_host`。

### 2.6 开发批次（G10 / G11）

权重合计 100 的 DEV-001～011 未合 main，故开发执行进度记 0%。现场状态以批次文件为准：

| 批次 | 目标 | 状态 |
|---|---|---|
| DEV-001 | 业态树与抽佣 | Ready（未合 main） |
| DEV-002 | 租户四套菜单 | Ready（未合 main） |
| DEV-003 | 入驻与审店 | In Progress |
| DEV-004 | 登录会话 | In Progress |
| DEV-005 | 用户分池 | In Progress |
| DEV-006 | 商品与审核 | In Progress |
| DEV-007 | 本地生活履约 | Ready（未合入） |
| DEV-008 | 本地生活拼团秒杀 | Ready（未合入） |
| DEV-009 | 订单支付结算 | Ready（未合入） |
| DEV-010 | 源品逛买 / 建 mall-online | Ready（未合入） |
| DEV-011 | 平台运营收口 | In Progress |
| DEV-012 | ToB 独立端 | Planned |
| DEV-013 | 源品闭口 / 商城拼团秒杀 / 板块 | In Progress |
| DEV-014 | 本地生活店资料先置 | In Progress |

---

## 3. AI 提示词资产与使用方式

### 3.1 拟改造的两份文件

| 文件 | 行数 | 作用 |
|---|---:|---|
| `docs/governance/common_prd_v3.1/通用文档提示词v3.1.md` | **2162** | 主提示词：目录、阶段、原则、第 1～52 节规则正文 |
| `docs/governance/common_prd_v3.1/通用文档提示词v3.1完整使用说明.md` | **2896** | 阶段门禁、可复制口令、第 2A 节知情决策、第 1A 节续窗口 |
| **合计** | **5058** | 每次新窗口要求完整加载 |

同目录配套（改造时可能要交叉引用，但不是本次必改正文）：

- `生成白话文档方案相关文档/`（7 份：总览/功能/分端/技术设计/架构图/文档地图/生成方案）

项目侧强制入口：

- `docs/project/AI_DOCUMENTATION_GUIDE.md`（每次必须遵循上述两份 + `PROJECT_VARIABLES.md`）
- `.cursor/rules/collaboration-judgment.mdc`
- `.cursor/rules/ui-spec-gate.mdc`（源品禁止跳步）
- `.cursor/rules/port-binding.mdc`

### 3.2 本仓库已经用过的提示词能力（统计口径）

这些数字说明 v3.1 **在本项目不是空转**，改造时要向后兼容，不能把已用口令拆掉：

| 能力 | 使用证据 | 规模 |
|---|---|---|
| G0～G11 全流程文档 | `docs/project` 742 文件 | 从 2026-09-04 起连续生产 |
| 知情决策 2A / DEC-042（一组最多 5 题） | DEC 73 + ADR 49 + CR 51 + UI-DEC 6 | 决策号已占用到 DEC-073 / ADR-049 / CR-051 |
| 第 1A 节新窗口续做 | 工作日志按日编号 | 220 篇 WORKLOG |
| 第 36A 节批次结束 CR | CR-042～051 等 | 变更稿纳入正式 PRD |
| 第 36B～36D 节对外白话 | `plain-document/` 71 文件 | 已启用 |
| 第 23A / 25A / 28A / 29 节 G9.5 | 源品 UI_SPEC 0.1.0→0.1.5 | 12 个 SPEC 文件 + Partial Contract |
| 第 32A 节视觉循环 | `ui-design/visual-loop/LOOP_RUNS/` | **7** 次运行 |
| 第 35 节点名开工 | DEV-013 / DEV-014 In Progress | 已改业务代码（历史事实；本次改造提示词不要再改这些代码） |
| Cursor 规则固化闸口 | `.cursor/rules/*.mdc` | 3 条常驻规则 |

### 3.3 工作日志（AI 会话落地痕迹）

`docs/project/progress/worklogs/`：**220** 篇 `WORKLOG-YYYYMMDD-NNN.md`。

| 日期 | 篇数 |
|---:|---:|
| 2026-09-04 | 41 |
| 2026-09-05 | 47 |
| 2026-09-06 | 29 |
| 2026-09-07 | 11 |
| 2026-09-08 | 10 |
| 2026-09-09 | 10 |
| 2026-09-10 | 13 |
| 2026-09-12 | 9 |
| 2026-09-15 | 3 |
| 2026-09-16 | 3 |
| 2026-09-17 | 11 |
| 2026-09-18 | 25 |
| 2026-09-19 | 8 |
| **合计** | **220** |

含义：约两周内，文档+实现是「多会话、多口令、按 G 阶段和批次推进」，不是一次生成。改造提示词必须保留：**每次只做一节/一批、新窗口用第 1A 节续、知情决策禁止弹框、G9.5 禁止跳步**。

### 3.4 本仓库已踩过、提示词改造不该回退的约束

1. **五端 × 多业态**：本地生活 / 源品 / ToB / 平台 / 租户，不能收成一个用户一个租户。
2. **编号占用 + 在引用保护**（v3.1.11 / v3.1.12）：73 个 DEC 已挂主题，禁止整篇换题清号。
3. **G9.5 跳步事故面**：令牌确认 ≠ 可换皮；用户预定页只记 Partial。已写入 Cursor 规则。
4. **端口表 = 确认**：源品 C 端禁止打 8032。
5. **自测不得改口径**（v3.1.13）：桩测完要拆。
6. **DEC-042**：一组最多 5 题；现码能收口则自决。
7. **文档阶段默认只改 `docs/project/`**；打开代码后只改点名批次。

---

## 4. 代码项目目录说明（现码，禁止本次改造去改）

技术栈（项目变量）：Go 1.24 + Gin/GORM（`nunu-go-api`）；后台 Vue3 + Vite + Element Plus；C 端 UniApp Vue3。共库，进程只作暴露面。

### 4.1 `nunu-go-api/`（后端 monorepo）

```text
nunu-go-api/
├── app/                      # 各独立进程
│   ├── admin/                # 平台后台 API 8031 + web/
│   ├── merchant/             # 租户后台 API 8033 + web/
│   ├── mall/                 # 本地生活 C 端 API 8032
│   ├── mall-online/          # 源品 C 端 API 8035
│   ├── mall-tob/             # ToB C 端 API 8037
│   ├── h5/                   # 入驻/本地生活 H5 静态 8034，挂 /wap/
│   ├── h5-online/            # 源品 H5 静态 8036，根路径
│   ├── h5-tob/               # ToB H5 静态 8038，挂 /wap/
│   └── home/                 # 骨架/健康检查类
├── model/                    # 共库领域模型
├── pkg/                      # 共享能力包（见下）
├── config/                   # 各进程 local/test/prod yml.example
├── deploy/sql/               # 增量 SQL（约 38 个）
├── Makefile
└── mall-uniapp/              # 忽略，不以它为真源
```

每个 API 进程典型内部：`cmd/server`（+ 部分 `task`/`migration`）、`internal/{handler,service,repository,router,server,middleware}`、`api/v1`。

**后台前端：**

- `app/admin/web/src/views/`：dashboard、merchant、goods、order、mall-campaign、content、tob、system…
- `app/merchant/web/src/views/`：goods、marketing、mall-campaign、shop、order、finance…

**`pkg/` 能力包（与 G7 技术模块对应，改造提示词时不要改这些名字）：**  
`businesstree`、`onboarding` 相关不单独列目录名时看 app、`goodssellable`、`groupseckill`、`fulfillment`、`trade`、`userpool`、`authsession`、`homemodule`、`mallcampaign`、`platformsection`、`nearbycps`、`shoparchive`、`decoration`、`jwt`、`wechat`、`sms`、`amap` 等。

### 4.2 三套 UniApp C 端

| 工程 | 服务对象 | 热更新 | API | H5 进程 |
|---|---|---|---|---|
| `go-uni-app` | 众享营销 - 本地生活 | 5175 `/wap/` | mall **8032** | `app/h5` 8034 `/wap/` |
| `go-uni-app-online` | 众享源品 - 在线商城 | 5176 根路径 | mall-online **8035** | `app/h5-online` 8036 根路径 |
| `go-uni-app-tob` | ToB 营销 | 5177 `/wap/` | mall-tob **8037** | `app/h5-tob` 8038 `/wap/` |

源品页面（换皮只动点名页，提示词改造不要去改 vue）：

```text
go-uni-app-online/src/
├── addon/shop/pages/
│   ├── indexPage/            # 首页、分类
│   ├── nearby/               # index-f 附近列表；details-f 店详情（未换皮）
│   ├── goods/                # 详情/购物车/收藏/足迹
│   ├── campaign/             # 拼团秒杀活动
│   ├── mine/
│   └── …
└── addon/shop/components/tabbar/
```

本地生活业务主要在 `go-uni-app/src/addon/fang_catering/`（附近、拼团秒杀坑、活动页）。

### 4.3 进程与端口对照（实现层）

| 进程目录 | 本机端口 | 调用方 |
|---|---|---|
| `app/admin` | 8031 | `app/admin/web` |
| `app/mall` | 8032 | `go-uni-app` |
| `app/merchant` | 8033 | `app/merchant/web` |
| `app/h5` | 8034 | 入驻/本地生活 H5 |
| `app/mall-online` | 8035 | `go-uni-app-online` |
| `app/h5-online` | 8036 | 源品 H5 |
| `app/mall-tob` | 8037 | `go-uni-app-tob` |
| `app/h5-tob` | 8038 | ToB H5 |

---

## 5. 当前项目状态（给提示词改造用的一句话版）

- 这是**已有项目功能扩展**：多业态租户入驻 + 本地生活 + 源品在线商城 + ToB 独立端。
- 文档体系已从 G0 走到 G11，**PRD 已 Approved 未 Baselined**，G6～G9 已 Baselined。
- 正式 UI 只对 **源品 `gongyi_online` 分闸**，UI_SPEC 0.1.5 Approved Partial；其它端无正式 UI_SPEC。
- 代码已按批次在 `feature/huanpipro` 上改过（mall-online、拼团秒杀坑、源品换皮等），**未合 main，开发执行进度仍记 0%**。
- AI 工作方式高度依赖 v3.1：**5058 行提示词 + 220 篇工作日志 + 73 DEC**。改造提示词等于改「以后所有窗口怎么干活」，不是改某一个页面。

---

## 6. 改造提示词时的保护清单（必须遵守）

1. **不改** `nunu-go-api/**`、`go-uni-app*/**`、`deploy/sql`、真实 `local.yml`。
2. **不改** 已批准/已盖章的 `docs/project/prd`、`baseline/DEC-*`、`decisions/ADR-*`、`changes/CR-*` 正文（除非用户另开口令做文档迁移）。
3. **保持** G0～G11 阶段名、第 1～52 节编号策略与本仓库已占用号段兼容（v3.1.15 迭代说明已写死「不新增 G 阶段、不改节号」——若新方案要改节号，必须先出对照表，不能直接打进正在用的仓库）。
4. **保持** 第 2A 节知情决策：只在会话正文提问，禁止弹框。
5. **保持** G9.5 顺序：`25A anydesign → 令牌确认 → 28A Draft UI_SPEC → 第 29 节批准 → 点名页换皮`。
6. **保持** 五端端口表与「源品只打 8035」。
7. 新窗口续做仍以 `PROJECT_DASHBOARD.md` + `PROGRESS_REGISTER.yaml` + DEC 为准，不要改成依赖聊天记忆。

---

## 7. 建议的下一步（本文不执行）

本文只做盘点，**没有改提示词、没有改代码**。

若开始改造，建议单独开窗口，只加载：

- 本文件
- `通用文档提示词v3.1.md`
- `通用文档提示词v3.1完整使用说明.md`

先出「提示词改造方案」（改哪些痛点、是否保持节号、如何兼容已占用 DEC/ADR），用户确认后再改那两份 md。
)
